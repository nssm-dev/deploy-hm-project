import { lazy, Suspense } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

// Eager load critical routes
import MainLayout from "./components/layout/MainLayout";
import Login from "./pages/Login";
import Register from "./pages/Register";

// Lazy load other pages for better performance
const Dashboard = lazy(() => import("./pages/Dashboard"));
const DoctorPP = lazy(() => import("./pages/DoctorPP"));
const Channel = lazy(() => import("./pages/Channel"));
const Admission = lazy(() => import("./pages/Admission"));
const Cashier = lazy(() => import("./pages/Cashier"));
const ServiceBooking = lazy(() => import("./pages/ServiceBooking"));
const ProfessionalMaster = lazy(() => import("./pages/ProfessionalMaster"));
const SpecialityMaster = lazy(() => import("./pages/SpecialityMaster"));

// Loading component
const LoadingFallback = () => (
  <div style={{ 
    display: 'flex', 
    justifyContent: 'center', 
    alignItems: 'center', 
    height: '100vh',
    backgroundColor: '#f0f1f6'
  }}>
    <div style={{
      width: '50px',
      height: '50px',
      border: '5px solid #e0e0e0',
      borderTop: '5px solid #0062ff',
      borderRadius: '50%',
      animation: 'spin 1s linear infinite'
    }} />
  </div>
);

function App() {
  return (
    <Router>
      <Suspense fallback={<LoadingFallback />}>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/" element={<MainLayout />}>
            <Route index element={<Dashboard />} />
            <Route path="dashboard" element={<Dashboard />} />

            {/* Front Desk */}
            <Route path="channel" element={<Channel />} />
            <Route path="admission" element={<Admission />} />
            <Route path="cashier" element={<Cashier />} />
            <Route path="service-booking" element={<ServiceBooking />} />
            <Route path="doctor-pp" element={<DoctorPP />} />
            <Route path="doctor-profile" element={<DoctorPP />} />
            <Route
              path="report-issue"
              element={<ComingSoon title="Report Issue" />}
            />

            {/* Master Files */}
            <Route path="professional-master" element={<ProfessionalMaster />} />
            <Route path="speciality-master" element={<SpecialityMaster />} />

          {/* Other Modules */}
          <Route path="service" element={<ComingSoon title="Service" />} />
          <Route path="inventory" element={<ComingSoon title="Inventory" />} />
          <Route
            path="human-resources"
            element={<ComingSoon title="Human Resources" />}
          />
          <Route path="payroll" element={<ComingSoon title="Payroll" />} />
          <Route
            path="financial-accounts"
            element={<ComingSoon title="Financial Accounts" />}
          />
          <Route path="patients" element={<ComingSoon title="Patients" />} />

          {/* User Menu */}
          <Route path="settings" element={<ComingSoon title="Settings" />} />
          <Route
            path="noticeboard"
            element={<ComingSoon title="Noticeboard" />}
          />
        </Route>
      </Routes>
      </Suspense>
    </Router>
  );
}

// Coming Soon Component
interface ComingSoonProps {
  title: string;
}

const ComingSoon: React.FC<ComingSoonProps> = ({ title }) => {
  return (
    <div
      className="p-6"
      style={{ backgroundColor: "#f0f1f6", minHeight: "calc(100vh - 64px)" }}
    >
      <div className="mb-6">
        <h1 className="text-2xl font-bold" style={{ color: "#001737" }}>
          {title}
        </h1>
        <p className="mt-2" style={{ color: "#a7afb7" }}>
          Module management and configuration
        </p>
      </div>
      <div
        className="bg-white rounded-lg shadow-md p-6"
        style={{ borderRadius: "0.3125rem" }}
      >
        <div className="text-center py-12">
          <svg
            className="mx-auto h-24 w-24 mb-4"
            style={{ color: "#8e94a9" }}
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={1.5}
              d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4"
            />
          </svg>
          <h3 className="text-lg font-medium mb-2" style={{ color: "#001737" }}>
            {title} Module
          </h3>
          <p style={{ color: "#a7afb7" }}>This feature is coming soon...</p>
        </div>
      </div>
    </div>
  );
};

export default App;
