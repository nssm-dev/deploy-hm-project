import {reduxStore} from "./store/store";

export interface IAuth {
    token: string;
}

export interface IAuthUserState {
    user: IAuth | null;
    loading: 'idle' | 'pending' | 'succeeded' | 'failed';
    error: string | null;
}


interface LoginCredentials {
    email: string;
    password: string;
}

export type RootState = ReturnType<typeof reduxStore.getState>

export type AppDispatch = typeof reduxStore.dispatch