import {createAsyncThunk} from "@reduxjs/toolkit";
import {API} from "../../api";
import {API_URL} from "../../api/url";
import type {IAuth, LoginCredentials} from "../type";

export const loginUser = createAsyncThunk<IAuth, LoginCredentials>(
    'users/login',
    async (credentials: LoginCredentials, {rejectWithValue}) => {
        try {
            const user = await API.post<IAuth>(API_URL.auth.login, credentials);
            console.log(user);
            if (user.status !== 200) {
                return rejectWithValue('login failed');
            }
            localStorage.setItem("hm-user-auth", JSON.stringify(user.data));
            return user.data;
        } catch (e) {
            return rejectWithValue('login failed');
        }
    },
)

export const registerUser = createAsyncThunk<IAuth, LoginCredentials>(
    'users/register',
    async (credentials: LoginCredentials, {rejectWithValue}) => {
        try {
            const user = await API.post<IAuth>(API_URL.auth.register, credentials);
            return user.data;
        } catch (e) {
            return rejectWithValue('login failed');
        }
    },
)