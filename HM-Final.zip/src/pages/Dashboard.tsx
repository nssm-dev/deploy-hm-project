import React from 'react';

interface StatItem {
  title: string;
  value: string;
  icon: string;
  color: string;
  change: string;
  changeType: string;
}

const Dashboard: React.FC = () => {
  const stats: StatItem[] = [
    { 
      title: 'Total Patients', 
      value: '1,234', 
      icon: 'M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z', 
      color: 'primary',
      change: '+12%',
      changeType: 'up'
    },
    { 
      title: 'Appointments Today', 
      value: '45', 
      icon: 'M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z', 
      color: 'success',
      change: '+8%',
      changeType: 'up'
    },
    { 
      title: 'Doctors Available', 
      value: '24', 
      icon: 'M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z', 
      color: 'warning',
      change: '+5%',
      changeType: 'up'
    },
    { 
      title: 'Revenue Today', 
      value: '$12,543', 
      icon: 'M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z', 
      color: 'danger',
      change: '+15%',
      changeType: 'up'
    },
  ];

  return (
    <div className="space-y-4 md:space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-600 mt-1 text-sm md:text-base">Welcome to NS HIMS</p>
        </div>
        <button className="btn-enhanced primary w-full sm:w-auto">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
          </svg>
          New Appointment
        </button>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
        {stats.map((stat, index) => (
          <div key={index} className={`card-stats ${stat.color}`}>
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <p className="text-white text-opacity-90 text-sm font-medium mb-2">{stat.title}</p>
                <h3 className="text-4xl font-bold text-white mb-3">{stat.value}</h3>
                <div className="flex items-center gap-2">
                  <span className="bg-white bg-opacity-20 text-white text-xs px-2 py-1 rounded-full font-semibold">
                    {stat.change}
                  </span>
                  <span className="text-white text-opacity-80 text-xs">vs last month</span>
                </div>
              </div>
              <div className="bg-white bg-opacity-20 p-3 rounded-lg">
                <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={stat.icon} />
                </svg>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4 md:gap-6">
        {/* Recent Appointments */}
        <div className="card-enhanced">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-gray-900">Recent Appointments</h2>
            <button className="text-primary hover:text-primary-dark text-sm font-semibold hover:underline transition-all">
              View All →
            </button>
          </div>
          <div className="space-y-3">
            {[
              { name: 'John Doe', time: '10:00 AM', dept: 'Cardiology', status: 'Confirmed', statusColor: 'success' },
              { name: 'Jane Smith', time: '11:30 AM', dept: 'Neurology', status: 'Pending', statusColor: 'warning' },
              { name: 'Mike Johnson', time: '02:00 PM', dept: 'Orthopedics', status: 'Confirmed', statusColor: 'success' }
            ].map((appointment, index) => (
              <div key={index} className="flex items-center gap-4 p-4 bg-gradient-to-r from-gray-50 to-white rounded-lg hover:shadow-md transition-all duration-200 cursor-pointer">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-primary-dark flex items-center justify-center text-white font-bold text-lg">
                  {appointment.name.charAt(0)}
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-gray-900">{appointment.name}</h4>
                  <p className="text-sm text-gray-600">{appointment.dept} • {appointment.time}</p>
                </div>
                <span className={`badge-enhanced ${appointment.statusColor}`}>
                  {appointment.status}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="card-enhanced">
          <h2 className="text-xl font-bold text-gray-900 mb-6">Quick Actions</h2>
          <div className="grid grid-cols-2 gap-4">
            {[
              { icon: 'M12 4v16m8-8H4', label: 'New Patient', color: 'primary' },
              { icon: 'M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z', label: 'Schedule', color: 'success' },
              { icon: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2', label: 'Reports', color: 'warning' },
              { icon: 'M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z', label: 'Settings', color: 'danger' }
            ].map((action, index) => (
              <button key={index} className={`btn-enhanced ${action.color} flex-col py-6`}>
                <svg className="w-8 h-8 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={action.icon} />
                </svg>
                <span className="text-sm font-semibold">{action.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
