import React, {useState} from "react";
import {API} from "../api";
import {API_URL} from "../api/url.ts";

interface PatientData {
    phone: string;
    firstName: string;
    middleName: string;
    lastName: string;
    nic: string;
    age: string;
    dob: string;
    gender: string;
    civilStatus: string;
}

interface AppointmentData {
    appoNo: string;
    patientCode: string;
    patientName: string;
    doctor: string;
    note: string;
    emergency: boolean;
}

interface QueueItem {
    pCode: string;
    appoNo: string;
    doctor: string;
    patient: string;
    paymentState: string;
    serviceState: string;
    stateColor: string;
}


const Channel: React.FC = () => {
    const [patientCode, setPatientCode] = useState<string>("");
    const [patientData, setPatientData] = useState<PatientData>({
        phone: "",
        firstName: "",
        middleName: "",
        lastName: "",
        nic: "",
        age: "",
        dob: "",
        gender: "Male",
        civilStatus: "Unmarried",
    });

    const [appointmentData, setAppointmentData] = useState<AppointmentData>({
        appoNo: "008",
        patientCode: "",
        patientName: "",
        doctor: "",
        note: "",
        emergency: false,
    });

    const [queueData] = useState<QueueItem[]>([
        {
            pCode: "1001001",
            appoNo: "001",
            doctor: "Doctor1",
            patient: "Sanka Illangakoon",
            paymentState: "Paid",
            serviceState: "Completed",
            stateColor: "success",
        },
        {
            pCode: "1001002",
            appoNo: "002",
            doctor: "Doctor2",
            patient: "Muhammad Aaquib",
            paymentState: "Paid",
            serviceState: "In progress",
            stateColor: "warning",
        },
        {
            pCode: "1001003",
            appoNo: "003",
            doctor: "Doctor3",
            patient: "Manjula Wijayakoon",
            paymentState: "Not Paid",
            serviceState: "Completed",
            stateColor: "success",
        },
        {
            pCode: "1001004",
            appoNo: "004",
            doctor: "Doctor1",
            patient: "Thineth Dhanushka",
            paymentState: "Not Paid",
            serviceState: "In progress",
            stateColor: "warning",
        },
        {
            pCode: "1001005",
            appoNo: "005",
            doctor: "Doctor4",
            patient: "Sajith Pathirana",
            paymentState: "Paid",
            serviceState: "In progress",
            stateColor: "warning",
        },
    ]);

    const handlePatientSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        console.log("Patient Data:", patientData);
        const sendData = {
            "phoneNumber": patientData.phone,
            "firstName": patientData.firstName,
            "middleName": patientData.middleName,
            "lastName": patientData.lastName,
            "nic": patientData.nic,
            "dateOfBirth": patientData.dob,
            "gender": patientData.gender,
            "patientCode": patientCode,
            "userName": "string"
        }
        try {
            const res = await API.post(API_URL.patient.create, sendData)
            console.log(res.data);
        } catch (e) {
            console.log(e);
        }
    };

    const handleAppointmentSubmit = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        console.log("Appointment Data:", appointmentData);
    };

    const generatePatientCode = () => {
        const newCode = `100${Math.floor(1000 + Math.random() * 9000)}`;
        setPatientCode(newCode);
        setPatientData({...patientData});
    };

    return (
        <div className="space-y-4 md:space-y-6">
            {/* Page Header */}
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                <div>
                    <h1 className="text-2xl md:text-3xl font-bold text-gray-900">
                        Patient Registration
                    </h1>
                    <nav className="text-sm breadcrumbs mt-1">
                        <ol className="flex items-center space-x-2 text-gray-600">
                            <li>
                                <a href="#" className="hover:text-primary">
                                    Front Desk
                                </a>
                            </li>
                            <li className="text-gray-400">/</li>
                            <li className="text-gray-900">Channel</li>
                        </ol>
                    </nav>
                </div>
            </div>

            {/* Registration Forms */}
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-4 md:gap-6">
                {/* Patient Details Form */}
                <div className="card-enhanced">
                    <h4 className="text-xl font-bold mb-6 text-gray-900">
                        Patient Details
                    </h4>
                    <div className="mb-4 flex items-center space-x-2">
                        <input
                            type="text"
                            className="input-enhanced flex-1"
                            value={patientCode}
                            placeholder="Patient Code"
                            readOnly
                        />
                        <button
                            onClick={generatePatientCode}
                            className="btn-enhanced max-w-fit primary h-[53px]"
                        >
                            Generate Code
                        </button>
                    </div>
                    <p className="text-sm text-gray-600 mb-4">Auto Gen</p>

                    <form onSubmit={handlePatientSubmit} className="space-y-4">
                        <div className="input-group-enhanced">
                            <label>Phone Number</label>
                            <input
                                type="tel"
                                className="input-enhanced"
                                value={patientData.phone}
                                onChange={(e) =>
                                    setPatientData({...patientData, phone: e.target.value})
                                }
                                placeholder="Enter phone number"
                            />
                        </div>

                        <div className="input-group-enhanced">
                            <label>Patient First Name</label>
                            <input
                                type="text"
                                className="input-enhanced"
                                value={patientData.firstName}
                                onChange={(e) =>
                                    setPatientData({...patientData, firstName: e.target.value})
                                }
                                placeholder="Name With Initials"
                            />
                        </div>
                        <div className="input-group-enhanced">
                            <label>Patient Middle Name</label>
                            <input
                                type="text"
                                className="input-enhanced"
                                value={patientData.middleName}
                                onChange={(e) =>
                                    setPatientData({...patientData, middleName: e.target.value})
                                }
                                placeholder="Name With Initials"
                            />
                        </div>
                        <div className="input-group-enhanced">
                            <label>Patient Last Name</label>
                            <input
                                type="text"
                                className="input-enhanced"
                                value={patientData.lastName}
                                onChange={(e) =>
                                    setPatientData({...patientData, lastName: e.target.value})
                                }
                                placeholder="Name With Initials"
                            />
                        </div>

                        <div>
                            <label className="block text-sm font-semibold text-gray-700 mb-1">
                                NIC Number
                            </label>
                            <input
                                type="text"
                                className="input-field"
                                value={patientData.nic}
                                onChange={(e) =>
                                    setPatientData({...patientData, nic: e.target.value})
                                }
                                placeholder="NIC Number"
                            />
                        </div>

                        <div>
                            <label className="block text-sm font-semibold text-gray-700 mb-1">
                                Age
                            </label>
                            <input
                                type="number"
                                className="input-field"
                                value={patientData.age}
                                onChange={(e) =>
                                    setPatientData({...patientData, age: e.target.value})
                                }
                                placeholder="Age"
                            />
                        </div>

                        <div>
                            <label className="block text-sm font-semibold text-gray-700 mb-1">
                                Date Of Birth
                            </label>
                            <input
                                type="date"
                                className="input-field"
                                value={patientData.dob}
                                onChange={(e) =>
                                    setPatientData({...patientData, dob: e.target.value})
                                }
                            />
                        </div>

                        <div>
                            <label className="block text-sm font-semibold text-gray-700 mb-1">
                                Gender
                            </label>
                            <select
                                className="input-field"
                                value={patientData.gender}
                                onChange={(e) =>
                                    setPatientData({...patientData, gender: e.target.value})
                                }
                            >
                                <option>Male</option>
                                <option>Female</option>
                                <option>Other</option>
                            </select>
                        </div>

                        {/*<div>*/}
                        {/*    <label className="block text-sm font-semibold text-gray-700 mb-1">*/}
                        {/*        Civil Status*/}
                        {/*    </label>*/}
                        {/*    <select*/}
                        {/*        className="input-field"*/}
                        {/*        value={patientData.civilStatus}*/}
                        {/*        onChange={(e) =>*/}
                        {/*            setPatientData({*/}
                        {/*                ...patientData,*/}
                        {/*                civilStatus: e.target.value,*/}
                        {/*            })*/}
                        {/*        }*/}
                        {/*    >*/}
                        {/*        <option>Married</option>*/}
                        {/*        <option>Unmarried</option>*/}
                        {/*        <option>N/A</option>*/}
                        {/*    </select>*/}
                        {/*</div>*/}

                        <div className="flex flex-col sm:flex-row gap-3">
                            <button
                                type="submit"
                                className="btn-enhanced primary w-full sm:w-auto"
                            >
                                Submit
                            </button>
                            <button
                                type="button"
                                className="btn-enhanced outline-secondary w-full sm:w-auto"
                            >
                                Reset
                            </button>
                        </div>
                    </form>
                </div>

                {/* OPD Booking Form */}
                <div className="card">
                    <h4 className="text-xl font-bold mb-4">OPD Booking</h4>
                    <p className="text-sm text-gray-600">Appointment No</p>
                    <input
                        type="text"
                        className="input-field text-5xl text-center my-4"
                        value={appointmentData.appoNo}
                        readOnly
                    />
                    <p className="text-sm text-gray-600 mb-4">Auto Gen</p>

                    <div className="mb-4">
                        <input
                            type="text"
                            className="input-field"
                            placeholder="Patient Code"
                            value={appointmentData.patientCode}
                            onChange={(e) =>
                                setAppointmentData({
                                    ...appointmentData,
                                    patientCode: e.target.value,
                                })
                            }
                        />
                        <p className="text-sm text-gray-600 mt-1">Auto Fill</p>
                    </div>

                    <form onSubmit={handleAppointmentSubmit} className="space-y-4">
                        <div>
                            <label className="block text-sm font-semibold text-gray-700 mb-1">
                                Patient Name
                            </label>
                            <input
                                type="text"
                                className="input-field"
                                value={appointmentData.patientName}
                                onChange={(e) =>
                                    setAppointmentData({
                                        ...appointmentData,
                                        patientName: e.target.value,
                                    })
                                }
                                placeholder="Auto Fill"
                            />
                        </div>

                        <div>
                            <label className="block text-sm font-semibold text-gray-700 mb-1">
                                Doctor
                            </label>
                            <select
                                className="input-field"
                                value={appointmentData.doctor}
                                onChange={(e) =>
                                    setAppointmentData({
                                        ...appointmentData,
                                        doctor: e.target.value,
                                    })
                                }
                            >
                                <option value="">Select Doctor</option>
                                <option>Doctor1</option>
                                <option>Doctor2</option>
                                <option>Doctor3</option>
                                <option>Doctor4</option>
                            </select>
                        </div>

                        <div>
                            <label className="block text-sm font-semibold text-gray-700 mb-1">
                                Note
                            </label>
                            <textarea
                                className="input-field"
                                rows={10}
                                value={appointmentData.note}
                                onChange={(e) =>
                                    setAppointmentData({
                                        ...appointmentData,
                                        note: e.target.value,
                                    })
                                }
                            ></textarea>
                        </div>

                        <div>
                            <label className="flex items-center">
                                <input
                                    type="checkbox"
                                    className="mr-2"
                                    checked={appointmentData.emergency}
                                    onChange={(e) =>
                                        setAppointmentData({
                                            ...appointmentData,
                                            emergency: e.target.checked,
                                        })
                                    }
                                />
                                <span className="text-sm font-semibold">Emergency</span>
                            </label>
                        </div>

                        <div className="flex flex-col sm:flex-row gap-3">
                            <button
                                type="submit"
                                className="btn-enhanced success w-full sm:w-auto"
                            >
                                Add
                            </button>
                            <button
                                type="button"
                                className="btn-enhanced outline-secondary w-full sm:w-auto"
                            >
                                Cancel
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            {/* Queue Details Table */}
            <div className="card-enhanced">
                <h4 className="text-xl font-bold mb-6 text-gray-900">Queue Details</h4>
                <div className="overflow-x-auto -mx-4 sm:mx-0">
                    <table className="w-full min-w-full">
                        <thead className="bg-gray-50">
                        <tr>
                            <th className="px-4 sm:px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase whitespace-nowrap">
                                P_Code
                            </th>
                            <th className="px-4 sm:px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase whitespace-nowrap">
                                Appo No.
                            </th>
                            <th className="px-4 sm:px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase whitespace-nowrap">
                                Doctor
                            </th>
                            <th className="px-4 sm:px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase whitespace-nowrap">
                                Patient
                            </th>
                            <th className="px-4 sm:px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase whitespace-nowrap">
                                Payment State
                            </th>
                            <th className="px-4 sm:px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase whitespace-nowrap">
                                Service State
                            </th>
                            <th className="px-4 sm:px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase whitespace-nowrap">
                                Actions
                            </th>
                        </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200">
                        {queueData.map((item, index) => (
                            <tr key={index} className="hover:bg-gray-50">
                                <td className="px-4 sm:px-6 py-4 font-medium whitespace-nowrap">
                                    {item.pCode}
                                </td>
                                <td className="px-4 sm:px-6 py-4 whitespace-nowrap">
                                    {item.appoNo}
                                </td>
                                <td className="px-4 sm:px-6 py-4 whitespace-nowrap">
                                    {item.doctor}
                                </td>
                                <td className="px-4 sm:px-6 py-4 whitespace-nowrap">
                                    {item.patient}
                                </td>
                                <td className="px-4 sm:px-6 py-4 whitespace-nowrap">
                                    {item.paymentState === "Not Paid" ? (
                                        <code className="text-red-600 font-semibold">
                                            {item.paymentState}
                                        </code>
                                    ) : (
                                        <span>{item.paymentState}</span>
                                    )}
                                </td>
                                <td className="px-4 sm:px-6 py-4 whitespace-nowrap">
                    <span
                        className={`bg-${item.stateColor} text-white px-3 py-1 rounded-full text-xs font-semibold`}
                    >
                      {item.serviceState}
                    </span>
                                </td>
                                <td className="px-4 sm:px-6 py-4 whitespace-nowrap">
                                    <button className="btn-enhanced warning text-sm">
                                        Edit
                                    </button>
                                </td>
                            </tr>
                        ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default Channel;
