import React, {useState} from 'react';

interface Tab {
    id: string;
    label: string;
}

const DoctorPP: React.FC = () => {
    const [activeTab, setActiveTab] = useState<string>('patients');
    const [patientCode, setPatientCode] = useState<string>('1001001');
    const [patientName, setPatientName] = useState<string>('Sanka Illangakoon');

    const tabs: Tab[] = [
        {id: 'patients', label: 'Patients'},
        {id: 'presenting', label: 'Presenting'},
        {id: 'examination', label: 'Examination'},
        {id: 'diagnosis', label: 'Diagnosis'},
        {id: 'investigation', label: 'Investigation'},
        {id: 'management', label: 'Management'},
    ];

    const patients = [
        {
            appoNo: '002',
            name: 'Muhammad Aaquib',
            age: 35,
            gender: 'Male',
            situation: 'Normal',
            situationColor: 'success'
        },
        {
            appoNo: '005',
            name: 'Sajith Pathirana',
            age: 30,
            gender: 'Male',
            situation: 'Emergency',
            situationColor: 'danger'
        },
    ];

    return (
        <div className="space-y-4 md:space-y-6">
            {/* Page Header */}
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                <div>
                    <h1 className="text-2xl md:text-3xl font-bold text-gray-900">Doctor PP</h1>
                    <nav className="text-sm breadcrumbs mt-1">
                        <ol className="flex items-center space-x-2 text-gray-600">
                            <li><a href="/channel" className="hover:text-primary">Front Desk</a></li>
                            <li className="text-gray-400">/</li>
                            <li className="text-gray-900">Doctor PP</li>
                        </ol>
                    </nav>
                </div>
            </div>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
                {/* Pending Count Card */}
                <div className="card text-center">
                    <h5 className="mb-4 text-gray-700 font-bold">Pending Count</h5>
                    <h2 className="text-5xl mb-4 text-gray-900 font-bold">5</h2>
                    <h5 className="mb-4 text-gray-700 font-bold">Next Number</h5>
                    <h2 className="text-5xl mb-4 text-gray-900 font-bold">002</h2>
                </div>

                {/* Current Number Card */}
                <div className="card text-center">
                    <h5 className="mb-4 text-gray-700 font-bold">Current Number</h5>
                    <h2 className="text-6xl mb-6 text-gray-900 font-bold">001</h2>
                    <div className="flex justify-center space-x-2">
                        <button className="btn-enhanced success">Next</button>
                        <button className="btn-enhanced warning">Hold</button>
                    </div>
                </div>

                {/* Hold Numbers Card */}
                <div className="card text-center">
                    <h5 className="mb-4 text-gray-700 font-bold">Hold Numbers</h5>
                    <div className="flex flex-wrap justify-center gap-2">
                        <span className="bg-danger text-white text-xl px-4 py-2 rounded font-bold">003</span>
                        <span className="bg-danger text-white text-xl px-4 py-2 rounded font-bold">004</span>
                    </div>
                </div>

                {/* Patient History Card */}
                <div className="card text-center">
                    <h5 className="mb-4 text-gray-700 font-bold">Patient History</h5>
                    <h2 className="text-2xl text-red-600 font-bold">Visit Count : 4</h2>
                    <h3 className="text-lg mt-4 mb-2 text-gray-900 font-bold">Last Visit Date</h3>
                    <h3 className="text-lg mb-4 text-gray-900 font-bold">05-04-2025</h3>
                    <h3 className="text-lg text-gray-900 font-bold">Date Count : 154</h3>
                </div>
            </div>

            {/* Search Section */}
            <div className="card">
                <div className="flex flex-col sm:flex-row sm:flex-wrap items-stretch sm:items-center gap-3">
                    <input
                        type="text"
                        className="input-field flex-1 min-w-0"
                        value={patientCode}
                        onChange={(e) => setPatientCode(e.target.value)}
                        placeholder="Patient Code"
                    />
                    <button className="btn-enhanced primary h-[51.56px] w-full sm:w-auto">Search</button>
                    <input
                        type="text"
                        className="input-field flex-1 min-w-0"
                        value={patientName}
                        onChange={(e) => setPatientName(e.target.value)}
                        placeholder="Patient Name"
                    />
                    <button className="btn-enhanced primary h-[51.56px] w-full sm:w-auto">Search</button>
                    <a href="/channel" className="btn-enhanced h-[51.56px] info text-center w-full sm:w-auto">
                        Edit Patient Details
                    </a>
                </div>
            </div>

            {/* Tabs */}
            <div className="card-enhanced">
                {/* Tab Headers */}
                <div className="tabs-enhanced overflow-x-auto">
                    {tabs.map((tab) => (
                        <button
                            key={tab.id}
                            onClick={() => setActiveTab(tab.id)}
                            className={`tab-enhanced ${activeTab === tab.id ? 'active' : ''}`}
                        >
                            {tab.label}
                        </button>
                    ))}
                </div>

                {/* Tab Content */}
                <div className="tab-content">
                    {/* Patients Tab */}
                    {activeTab === 'patients' && (
                        <div className="overflow-x-auto">
                            <table className="w-full">
                                <thead className="bg-gray-50">
                                <tr>
                                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Appo
                                        No.
                                    </th>
                                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Patient</th>
                                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Age</th>
                                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Gender</th>
                                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Situation</th>
                                </tr>
                                </thead>
                                <tbody className="divide-y divide-gray-200">
                                {patients.map((patient, index) => (
                                    <tr key={index} className="hover:bg-gray-50">
                                        <td className="px-6 py-4">{patient.appoNo}</td>
                                        <td className="px-6 py-4 font-medium">{patient.name}</td>
                                        <td className="px-6 py-4">{patient.age}</td>
                                        <td className="px-6 py-4">{patient.gender}</td>
                                        <td className="px-6 py-4">
                        <span
                            className={`bg-${patient.situationColor} text-white px-3 py-1 rounded-full text-xs font-semibold`}>
                          {patient.situation}
                        </span>
                                        </td>
                                    </tr>
                                ))}
                                </tbody>
                            </table>
                        </div>
                    )}

                    {/* Presenting Tab */}
                    {activeTab === 'presenting' && (
                        <div className="space-y-6">
                            <div>
                                <h4 className="text-lg font-bold mb-3">Presenting Complain</h4>
                                <textarea className="input-field" rows={4}></textarea>
                                <div className="mt-3 space-x-2">
                                    <button className="btn-enhanced primary">Keep</button>
                                    <button className="btn-enhanced h-[45px] outline-secondary">History</button>
                                </div>
                                <textarea className="input-field mt-3" rows={4} placeholder="Last Visit"
                                          readOnly></textarea>
                            </div>

                            <div>
                                <h4 className="text-lg font-bold mb-3">Medical</h4>
                                <textarea className="input-field" rows={4}></textarea>
                                <div className="mt-3 space-x-2">
                                    <button className="btn-enhanced primary">Keep</button>
                                    <button className="btn-enhanced h-[45px] outline-secondary">History</button>
                                </div>
                                <textarea className="input-field mt-3" rows={4} placeholder="Last Visit"
                                          readOnly></textarea>
                            </div>

                            <div>
                                <h4 className="text-lg font-bold mb-3">Surgical</h4>
                                <textarea className="input-field" rows={4}></textarea>
                                <div className="mt-3 space-x-2">
                                    <button className="btn-enhanced primary">Keep</button>
                                    <button className="btn-enhanced h-[45px] outline-secondary">History</button>
                                </div>
                                <textarea className="input-field mt-3" rows={4} placeholder="Last Visit"
                                          readOnly></textarea>
                            </div>

                            <div>
                                <h4 className="text-lg font-bold mb-3">Allergy</h4>
                                <textarea className="input-field" rows={4}></textarea>
                                <div className="mt-3 space-x-2">
                                    <button className="btn-enhanced primary">Keep</button>
                                    <button className="btn-enhanced h-[45px] outline-secondary">History</button>
                                </div>
                                <textarea className="input-field mt-3" rows={4} placeholder="Last Visit"
                                          readOnly></textarea>
                            </div>
                        </div>
                    )}

                    {/* Examination Tab */}
                    {activeTab === 'examination' && (
                        <div className="space-y-6">
                            {['General', 'Cardio Vascular', 'Respiratory', 'Central Nerve', 'Gastro Intestinal'].map((title) => (
                                <div key={title}>
                                    <h4 className="text-lg font-bold mb-3">{title}</h4>
                                    <textarea className="input-field" rows={4}></textarea>
                                    <div className="mt-3 space-x-2">
                                        <button className="btn-enhanced primary">Keep</button>
                                        <button className="btn-enhanced danger">Remove</button>
                                        <button className="btn-enhanced h-[45px] outline-secondary">History</button>
                                    </div>
                                    <div className="mt-3">
                                        <textarea className="input-field" rows={4}
                                                  placeholder="Informational text"></textarea>
                                        <label className="flex items-center mt-2">
                                            <input type="checkbox" className="mr-2"/>
                                            <span className="text-sm">Remove</span>
                                        </label>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}

                    {/* Diagnosis Tab */}
                    {activeTab === 'diagnosis' && (
                        <div className="space-y-6">
                            <div>
                                <h4 className="text-lg font-bold mb-3">Current</h4>
                                <textarea className="input-field" rows={4}></textarea>
                                <div className="mt-3 space-x-2">
                                    <button className="btn-enhanced primary">Keep</button>
                                    <button className="btn-enhanced danger">Remove</button>
                                </div>
                                <div className="mt-3">
                                    <textarea className="input-field" rows={8}
                                              placeholder="Informational text"></textarea>
                                    <label className="flex items-center mt-2">
                                        <input type="checkbox" className="mr-2"/>
                                        <span className="text-sm">Remove</span>
                                    </label>
                                </div>
                            </div>

                            {['05-04-2025', '01-03-2025', '10-12-2024'].map((date) => (
                                <div key={date}>
                                    <label className="text-sm font-semibold text-gray-700 mb-2 block">{date}</label>
                                    <textarea className="input-field" rows={4}></textarea>
                                </div>
                            ))}
                        </div>
                    )}

                    {/* Investigation Tab */}
                    {activeTab === 'investigation' && (
                        <div className="space-y-6">
                            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                                {/* Test Selection */}
                                <div className="card">
                                    <input type="text" className="input-field mb-4" placeholder="Search"/>
                                    <div className="flex items-center gap-5 flex-wrap">
                                        {['ESR', 'FBC', 'UFR', 'TSH', 'Test', 'Test'].map((test, index) => (
                                            <label key={index} className="flex items-center">
                                                <input type="checkbox" className="mr-2"/>
                                                <span>{test}</span>
                                            </label>
                                        ))}
                                    </div>
                                    <div className="mt-4 space-y-2 md:space-x-2">
                                        <button className="btn-enhanced success">Add</button>
                                        <button className="btn-enhanced info">Add New Test</button>
                                    </div>
                                </div>

                                {/* Prescribed Tests */}
                                <div className="card">
                                    <h4 className="text-lg font-bold mb-4">Prescribed</h4>
                                    <div className="flex flex-wrap gap-2 mb-6">
                                        {['ESR', 'FBC', 'TSH', 'Test1'].map((test) => (
                                            <span key={test}
                                                  className="bg-info text-white px-4 py-2 rounded-lg text-lg font-semibold">
                        {test}
                      </span>
                                        ))}
                                    </div>
                                    <button className="btn-enhanced primary mt-auto">Print Prescription</button>
                                </div>
                            </div>

                            {/* Test Results by Date */}
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                {['Today', '05-04-2025', '01-03-2025', '10-12-2024'].map((date) => (
                                    <div key={date} className="card">
                                        <h4 className="text-lg font-bold mb-4">{date}</h4>
                                        <div className="space-y-3">
                                            <div>
                                                <label className="block text-sm font-semibold mb-1">ESR</label>
                                                <input type="text" className="input-field mb-2" placeholder="Value"/>
                                                <input type="text" className="input-field" placeholder="Ref Range"/>
                                            </div>
                                            <div>
                                                <label className="block text-sm font-semibold mb-1">Comments</label>
                                                <textarea className="input-field" rows={4}></textarea>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}

                    {/* Management Tab */}
                    {activeTab === 'management' && (
                        <div className="space-y-6">
                            {/* Drug Stock Table */}
                            <div className="overflow-x-auto">
                                <table className="w-full">
                                    <thead className="bg-gray-50">
                                    <tr>
                                        <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Code</th>
                                        <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Drug</th>
                                        <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Exp
                                            Date
                                        </th>
                                        <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Stock</th>
                                    </tr>
                                    </thead>
                                    <tbody className="divide-y divide-gray-200">
                                    <tr className="hover:bg-gray-50">
                                        <td className="px-6 py-4">10001</td>
                                        <td className="px-6 py-4 font-medium">PARACETAMOL</td>
                                        <td className="px-6 py-4">
                                            <span
                                                className="bg-danger text-white px-3 py-1 rounded-full text-xs font-semibold">30-11-2025</span>
                                        </td>
                                        <td className="px-6 py-4">2300</td>
                                    </tr>
                                    <tr className="hover:bg-gray-50">
                                        <td className="px-6 py-4">10005</td>
                                        <td className="px-6 py-4 font-medium">AMOXICILLIN</td>
                                        <td className="px-6 py-4">
                                            <span
                                                className="bg-success text-white px-3 py-1 rounded-full text-xs font-semibold">31-12-2028</span>
                                        </td>
                                        <td className="px-6 py-4">930</td>
                                    </tr>
                                    <tr className="hover:bg-gray-50">
                                        <td className="px-6 py-4">10012</td>
                                        <td className="px-6 py-4 font-medium">PIRITON</td>
                                        <td className="px-6 py-4">
                                            <span
                                                className="bg-warning text-white px-3 py-1 rounded-full text-xs font-semibold">10-01-2026</span>
                                        </td>
                                        <td className="px-6 py-4">560</td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>

                            {/* Drug Prescription Interface */}
                            <div className="card space-y-4">
                                <div className="flex flex-wrap items-center gap-3">
                                    <input type="text" className="input-field flex-1" placeholder="Search"/>
                                    <button
                                        className="btn bg-gray-800 text-white h-[51.56px] hover:bg-gray-900 font-semibold py-2 px-4 rounded">Search
                                    </button>
                                    <input type="text" className="input-field w-32" placeholder="Units"/>
                                    <button className="btn-success">NOS</button>
                                    <button className="btn-success">ML</button>
                                    <span className="bg-info text-white px-4 py-[13px] rounded text-sm">Press 1st ltr with Shift key</span>
                                </div>

                                <div className="flex flex-wrap items-center gap-3">
                                    <button className="btn-success">Mane (1)</button>
                                    <button className="btn-warning">Nocte (2)</button>
                                    <button className="btn-primary">TDS (3)</button>
                                    <button
                                        className="btn bg-info text-white hover:bg-blue-600 h-[45.78px] font-semibold py-2 px-4 rounded">QDS
                                        (4)
                                    </button>
                                    <input type="text" className="input-field flex-1" placeholder="Enter Text"/>
                                    <button className="btn-danger h-[51.56px]">Hourly (5)</button>
                                    <input type="text" className="input-field w-32" placeholder="Enter Text"/>
                                    <input type="text" className="input-field w-48"
                                           placeholder="Qty (Auto Calculated)"/>
                                    <button
                                        className="btn bg-gray-800 text-white hover:bg-gray-900 font-semibold py-2 px-4 rounded">Add
                                    </button>
                                    <button
                                        className="btn bg-gray-800 text-white hover:bg-gray-900 font-semibold py-2 px-4 rounded">Print
                                        Prescription
                                    </button>
                                </div>
                            </div>

                            {/* History Tables */}
                            {['05-04-2025', '01-03-2025'].map((date) => (
                                <div key={date} className="card">
                                    <h4 className="text-lg font-bold mb-2">History</h4>
                                    <h4 className="text-lg font-bold mb-4 text-primary">{date}</h4>
                                    <div className="overflow-x-auto">
                                        <table className="w-full">
                                            <thead className="bg-gray-50">
                                            <tr>
                                                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Drug</th>
                                                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Type</th>
                                                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Days</th>
                                            </tr>
                                            </thead>
                                            <tbody className="divide-y divide-gray-200">
                                            <tr className="hover:bg-gray-50">
                                                <td className="px-6 py-4 font-medium">PARACETAMOL</td>
                                                <td className="px-6 py-4">pain and to lower a fever</td>
                                                <td className="px-6 py-4">3</td>
                                            </tr>
                                            <tr className="hover:bg-gray-50">
                                                <td className="px-6 py-4 font-medium">AMOXICILLIN</td>
                                                <td className="px-6 py-4">Type</td>
                                                <td className="px-6 py-4">3</td>
                                            </tr>
                                            <tr className="hover:bg-gray-50">
                                                <td className="px-6 py-4 font-medium">PIRITON</td>
                                                <td className="px-6 py-4">type</td>
                                                <td className="px-6 py-4">3</td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default DoctorPP;
