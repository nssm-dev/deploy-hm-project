import axios from "axios";
import {API_URL} from "./url";

export const API = axios.create({
    baseURL: API_URL.base,
    headers: {
        "Content-Type": "application/json",
    }
})