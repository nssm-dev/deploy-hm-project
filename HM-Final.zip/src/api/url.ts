export const API_URL = {
    base: 'http://cloud.ninesense.lk:3001/',
    auth: {
        login: 'api/Authentication/login',
        register: 'api/Authentication/register',
    },
    patient: {
        create: 'api/Patient',
        update: 'api/Patient',
        delete: 'api/Patient',
        get: 'api/Patient',
    },
    appointment: {
        create: 'api/Appointment',
        update: 'api/Appointment',
        delete: 'api/Appointment',
        get: 'api/Appointment',
    }
}