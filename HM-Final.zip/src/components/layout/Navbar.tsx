import React, { useState } from 'react';
import { Link } from 'react-router-dom';

interface NavbarProps {
  toggleSidebar: () => void;
  toggleMinimize: () => void;
  isMinimized: boolean;
}

const Navbar: React.FC<NavbarProps> = ({ toggleSidebar, toggleMinimize, isMinimized }) => {
  const [profileDropdown, setProfileDropdown] = useState<boolean>(false);
  const [messageDropdown, setMessageDropdown] = useState<boolean>(false);
  const [notificationDropdown, setNotificationDropdown] = useState<boolean>(false);

  const SIDEBAR_WIDTH = 258;
  const SIDEBAR_MINI_WIDTH = 70;
  const brandWidth = isMinimized ? SIDEBAR_MINI_WIDTH : SIDEBAR_WIDTH;
  const toggleButtonLeft = isMinimized ? `${SIDEBAR_MINI_WIDTH + 8}px` : `${SIDEBAR_WIDTH + 8}px`;

  return (
    <nav className="fixed top-0 left-0 right-0 bg-white shadow-md h-16" style={{ height: '64px', zIndex: 60 }}>
      <div className="flex items-center justify-between h-full pr-4 pl-4 lg:pl-0">
        {/* Logo and Toggle */}
        <div className="flex items-center" style={{ flexShrink: 0 }}>
          {/* Mobile Logo - Always show on small screens */}
          <Link
            to="/"
            className="lg:hidden flex items-center"
            style={{ backgroundColor: '#181824', padding: '0 1.5rem', height: '64px' }}
          >
            <img src="/assets/images/NS_logo.svg" alt="NS HIMS" className="h-8" />
          </Link>

          {/* Desktop brand block */}
          <Link
            to="/"
            className="hidden lg:flex items-center"
            style={{
              width: `${brandWidth}px`,
              height: '64px',
              backgroundColor: '#181824',
              padding: isMinimized ? '0' : '0 1.5rem',
              justifyContent: isMinimized ? 'center' : 'flex-start',
              transition: 'width 0.3s ease',
              borderRight: '1px solid rgba(255,255,255,0.06)',
              overflow: 'hidden',
            }}
          >
            {isMinimized ? (
              <img src="/assets/images/NS-logo-mini.svg" alt="Nine Sense" className="h-8 w-8" />
            ) : (
              <>
                <img src="/assets/images/NS_logo.svg" alt="Nine Sense" className="h-8" />
                <span
                  style={{
                    marginLeft: '12px',
                    color: '#ffffff',
                    fontWeight: 700,
                    fontSize: '0.95rem',
                    letterSpacing: '0.08em',
                    textTransform: 'uppercase',
                    whiteSpace: 'nowrap',
                  }}
                >
                  Nine Sense
                </span>
              </>
            )}
          </Link>
        </div>

        {/* Minimize/Expand Button - Desktop (Always visible) */}
        <button
          onClick={toggleMinimize}
          className="hidden lg:flex items-center justify-center absolute top-1/2 transform -translate-y-1/2 p-2 rounded-md hover:bg-gray-100 transition-all"
          style={{ 
            color: '#8e94a9',
            left: toggleButtonLeft,
            transition: 'left 0.3s ease-in-out',
          }}
          title={isMinimized ? "Expand Sidebar" : "Minimize Sidebar"}
        >
          {isMinimized ? (
            // Right double arrow when minimized (expand icon)
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 5l7 7-7 7M5 5l7 7-7 7" />
            </svg>
          ) : (
            // Hamburger when expanded (minimize icon)
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          )}
        </button>

        {/* Mobile Menu Toggle */}
        <button
          onClick={toggleSidebar}
          className="lg:hidden p-2 rounded-md hover:bg-gray-100"
          style={{ color: '#8e94a9' }}
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>

        {/* Search Bar */}
        <div className="hidden xl:flex flex-1 max-w-md mx-8">
          <div className="relative w-full">
            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none" style={{ color: '#8e94a9' }}>
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
            <input
              type="text"
              className="w-full pl-10 pr-4 py-2 border-0 rounded-lg focus:ring-2 focus:ring-primary focus:outline-none"
              style={{ backgroundColor: '#eef0fa', fontSize: '0.875rem' }}
              placeholder="Search"
            />
          </div>
        </div>

        {/* Right Side Items */}
        <div className="flex items-center space-x-4">
          {/* Notifications Dropdown */}
          <div className="relative">
            <button
              onClick={() => setNotificationDropdown(!notificationDropdown)}
              className="relative p-2 rounded-full hover:bg-gray-100"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
              </svg>
              <span className="absolute top-1 right-1 w-2 h-2 bg-danger rounded-full"></span>
            </button>

            {notificationDropdown && (
              <div className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-lg overflow-hidden z-50">
                <div className="bg-primary text-white px-4 py-3">
                  <h6 className="font-semibold">Notifications</h6>
                </div>
                <div className="max-h-96 overflow-y-auto">
                  <div className="p-4 hover:bg-gray-50 border-b">
                    <div className="flex items-start space-x-3">
                      <div className="flex-shrink-0 w-10 h-10 bg-success rounded-full flex items-center justify-center text-white">
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                        </svg>
                      </div>
                      <div className="flex-1">
                        <h6 className="text-sm font-semibold">Event today</h6>
                        <p className="text-xs text-gray-500">Just a reminder that you have an event today</p>
                      </div>
                    </div>
                  </div>
                  <div className="p-4 hover:bg-gray-50 border-b">
                    <div className="flex items-start space-x-3">
                      <div className="flex-shrink-0 w-10 h-10 bg-warning rounded-full flex items-center justify-center text-white">
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                        </svg>
                      </div>
                      <div className="flex-1">
                        <h6 className="text-sm font-semibold">Settings</h6>
                        <p className="text-xs text-gray-500">Update dashboard</p>
                      </div>
                    </div>
                  </div>
                  <div className="p-4 hover:bg-gray-50 border-b">
                    <div className="flex items-start space-x-3">
                      <div className="flex-shrink-0 w-10 h-10 bg-info rounded-full flex items-center justify-center text-white">
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
                        </svg>
                      </div>
                      <div className="flex-1">
                        <h6 className="text-sm font-semibold">Launch Admin</h6>
                        <p className="text-xs text-gray-500">New admin wow!</p>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="p-3 text-center bg-gray-50 border-t">
                  <button className="text-sm text-primary hover:text-primary-dark font-medium">
                    See all notifications
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Messages Dropdown */}
          <div className="relative">
            <button
              onClick={() => setMessageDropdown(!messageDropdown)}
              className="relative p-2 rounded-full hover:bg-gray-100"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
              </svg>
              <span className="absolute top-1 right-1 w-2 h-2 bg-success rounded-full"></span>
            </button>

            {messageDropdown && (
              <div className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-lg overflow-hidden">
                <div className="bg-primary text-white px-4 py-3">
                  <h6 className="font-semibold">Messages</h6>
                </div>
                <div className="max-h-96 overflow-y-auto">
                  <div className="p-4 hover:bg-gray-50 border-b">
                    <div className="flex items-start space-x-3">
                      <div className="flex-1">
                        <h6 className="text-sm font-semibold">Sanka send you a message</h6>
                        <p className="text-xs text-gray-500">1 Minutes ago</p>
                      </div>
                    </div>
                  </div>
                  <div className="p-4 hover:bg-gray-50 border-b">
                    <div className="flex items-start space-x-3">
                      <div className="flex-1">
                        <h6 className="text-sm font-semibold">Aaquib send you a message</h6>
                        <p className="text-xs text-gray-500">15 Minutes ago</p>
                      </div>
                    </div>
                  </div>
                  <div className="p-4 hover:bg-gray-50 border-b">
                    <div className="flex items-start space-x-3">
                      <div className="flex-1">
                        <h6 className="text-sm font-semibold">Manjula send you a message</h6>
                        <p className="text-xs text-gray-500">18 Minutes ago</p>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="p-3 text-center bg-gray-50 border-t">
                  <button className="text-sm text-primary hover:text-primary-dark font-medium">
                    4 new messages
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Profile Dropdown */}
          <div className="relative">
            <button
              onClick={() => setProfileDropdown(!profileDropdown)}
              className="flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-100"
            >
              <img
                src="/assets/images/faces-clipart/pic-1.png"
                alt="Admin"
                className="w-8 h-8 rounded-full"
              />
              <span className="hidden md:block font-medium">Admin</span>
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
              </svg>
            </button>

            {profileDropdown && (
              <div className="absolute right-0 mt-2 w-64 bg-white rounded-lg shadow-lg overflow-hidden">
                <div className="bg-primary text-white px-4 py-3 text-center">
                  <img
                    src="/assets/images/faces-clipart/pic-1.png"
                    alt="Admin"
                    className="w-12 h-12 rounded-full mx-auto mb-2"
                  />
                </div>
                <div className="p-2">
                  <h6 className="px-3 py-2 text-xs font-semibold text-gray-600 uppercase">User Options</h6>
                  <Link to="#" className="flex items-center justify-between px-3 py-2 hover:bg-gray-100 rounded">
                    <span>Inbox</span>
                    <div className="flex items-center space-x-2">
                      <span className="bg-primary text-white text-xs px-2 py-1 rounded">3</span>
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                      </svg>
                    </div>
                  </Link>
                  <Link to="#" className="flex items-center justify-between px-3 py-2 hover:bg-gray-100 rounded">
                    <span>Profile</span>
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                    </svg>
                  </Link>
                  <Link to="#" className="flex items-center justify-between px-3 py-2 hover:bg-gray-100 rounded">
                    <span>Settings</span>
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                  </Link>
                  <hr className="my-2" />
                  <h6 className="px-3 py-2 text-xs font-semibold text-gray-600 uppercase">Actions</h6>
                  <Link to="#" className="flex items-center justify-between px-3 py-2 hover:bg-gray-100 rounded">
                    <span>Lock Account</span>
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                    </svg>
                  </Link>
                  <Link to="/login" className="flex items-center justify-between px-3 py-2 hover:bg-gray-100 rounded text-red-600">
                    <span>Log Out</span>
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                    </svg>
                  </Link>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
