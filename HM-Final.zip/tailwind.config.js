/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  safelist: [
    // Dynamic classes that might not be detected
    "bg-success",
    "bg-warning",
    "bg-danger",
    "bg-info",
    "bg-primary",
    "text-success",
    "text-warning",
    "text-danger",
    "text-info",
    "text-primary",
  ],
  theme: {
    extend: {
      colors: {
        // Theme Colors - Exact from HTML
        primary: {
          DEFAULT: "#0062ff",
          light: "#3d8bff",
          dark: "#0050d4",
        },
        secondary: {
          DEFAULT: "#8e94a9",
          light: "#a5aaba",
          dark: "#777d98",
        },
        success: "#44ce42",
        warning: "#ffc542",
        danger: "#fc5a5a",
        info: "#a461d8",
        dark: "#001737",
        light: "#aab2bd",

        // Base Colors from HTML
        blue: "#5E50F9",
        indigo: "#6610f2",
        purple: "#6a008a",
        pink: "#E91E63",
        red: "#f96868",
        orange: "#f2a654",
        yellow: "#f6e84e",
        green: "#46c35f",
        teal: "#58d8a3",
        cyan: "#57c7d4",
        violet: "#41478a",

        // Gray Scale
        gray: {
          DEFAULT: "#434a54",
          light: "#aab2bd",
          lighter: "#e8eff4",
          lightest: "#e6e9ed",
          dark: "#0f1531",
        },

        // Background Colors
        "content-bg": "#f0f1f6",
        "white-smoke": "#f2f7f8",
      },
      fontFamily: {
        ubuntu: ["Ubuntu", "sans-serif"],
        nunito: ["Nunito", "sans-serif"],
      },
    },
  },
  plugins: [],
};
